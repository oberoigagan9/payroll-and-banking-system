package com.cg.payroll.client;

import java.util.Scanner;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		
		Scanner sc=new Scanner(System.in);
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails("Roshan", "Jha", "Analyst", "Staff", "dwd10605", "jharoshan@gmail.com", 1500000, 125468975, "Hdfc", "fttg", 50000, 2000,5000);
		System.out.println("Associate Id: "+associateId);
		int associateId1=services.acceptAssociateDetails("harsh", "priya", "Analyst", "Staff", "dwd10605", "jharoshan@gmail.com", 1600000, 24514689, "Hdfc", "fttg", 40000, 2000,4000);
		System.out.println("Associate Id: "+associateId1);
		
	System.out.println("enter the employee Id you want to search");
	int num=sc.nextInt();
	System.out.println(services.getAssociateDetails(num));
	double  netSalary=services.calculateNetSalary(num);
	System.out.println("the netsalary is ="+netSalary);
	double grossSalary=services.calculateAnnualGrossSalary(num);
	System.out.println("the gross salary is= "+grossSalary);
	
		
	}
}
