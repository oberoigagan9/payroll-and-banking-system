package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayRollDBUtil;

public class AssociateDAOImpl implements AssociateDAO {

	@Override
	public Associate save(Associate associate) {
		associate.setAssociatedId(PayRollDBUtil.getASSOCIATE_ID_COUNTER());
		PayRollDBUtil.associates.put(associate.getAssociatedId(), associate);
		return associate;
	
	}

	@Override
	public boolean update(Associate associateId) {
		
		return false;
	}

	@Override
	public Associate findOne(int associateId) {
		return PayRollDBUtil.associates.get(associateId);
		
	}

	@Override
	public List<Associate> findAll() {
		return new ArrayList<>( PayRollDBUtil.associates.values());
		
	}
	

}
