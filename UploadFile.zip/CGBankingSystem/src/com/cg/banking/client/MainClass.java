package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidAccountTypeException, InvalidAccountException, BankingServiceDownException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException {
		int accNo,pinNo,accNo2;
		float amount;
		BankingServices bankingServices=new BankingServicesImpl();
		Account c1=null;
		Account c2=null;
		c1=bankingServices.openAccount("Savings ",3000);
		c1.setAccountStatus("Active");
		c2=bankingServices.openAccount("Savings ", 8000);
		c2.setAccountStatus("Active");
		
		System.out.println("Account details :\n"+c1);
		System.out.println("Account details :\n"+c2);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("*******************WITHDRAWL**************************");
		System.out.println("Enter the accoun number from which money is to be withdrawn");
		accNo=sc.nextInt();
		System.out.println("enter pin number of the account");
		pinNo=sc.nextInt();
		System.out.println("enter amount of money to be withdrawn");
		amount=sc.nextInt();
		System.out.println(bankingServices.withdrawAmount(accNo,amount,pinNo));
		System.out.println("Account details after withdrawl"+bankingServices.getAccountDetails(accNo));
		System.out.println("********************FUNDTRANSFER********************");
		System.out.println("Enter account number in which money is to be deposited");
		accNo=sc.nextInt();
		System.out.println("Enter account number from which money is to be transfered");
		 accNo2 = sc.nextInt();
		System.out.println("enter pin number of the account");
		pinNo=sc.nextInt();
		System.out.println("enter amount of money to be deposited");
		amount=sc.nextInt();
	boolean b=bankingServices.fundTransfer(accNo, accNo2, amount, pinNo);
	if(b==true)
	{
		System.out.println("ACCOUNT DETAILS AFTER TRANSFER"+bankingServices.getAccountDetails(accNo));
		System.out.println(bankingServices.getAccountDetails(accNo2));
	}
		System.out.println("*******************DEPOSIT********************");
		System.out.println("Enter account number in which money is to be deposited");
		accNo=sc.nextInt();
		System.out.println("enter amount of money to be deposited");
		amount=sc.nextInt();
		System.out.println("ACCOUNT details after deposit "+bankingServices.depositAmount(accNo, amount));
		
		
		
	}

}
