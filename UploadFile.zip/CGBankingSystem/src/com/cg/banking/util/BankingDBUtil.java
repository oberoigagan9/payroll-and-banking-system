package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public class BankingDBUtil {
public static HashMap<Long, Account> customer=new HashMap<>();
private static int ACCOUNT_NUMBER=100;
private static int TRANSACTION_NUMBER=100;
public static int getACCOUNT_NUMBER() {
	return ++ACCOUNT_NUMBER;
}
public static int getPIN_NUMBER() {
	return(int)(Math.random()*10000);
}
	public static int getTRANSACTION_NUMBER() {
		return ++ TRANSACTION_NUMBER;
	
}
	
	
}


